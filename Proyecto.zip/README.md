# Proyecto Web - HACKABOSS Enero

*Desarrollado por:*
*Daniel Eireos,*
*Alicia Lavandeira,* 
*Adrián López,*
*Andrea Morais* 
*y*
*Daniel Veiga.*  


## Desarrollo de una página web  
### JUEGO: *ENCUENTRA EL COLOR 🎨*  

Este juego consiste en una pantalla que te muestra por un lado un color en código RGB, y por el otro una selección de colores similares entre las que tendrás que escoger el idéntico al enunciado.   

El juego cuenta con un sistema de aciertos y errores:
* 3 respuestas correctas darían la victoria ✅
* 3 incorrectas significarían el fracaso ❌
